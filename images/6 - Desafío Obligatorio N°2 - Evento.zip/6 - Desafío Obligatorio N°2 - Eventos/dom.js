const productStock = [
    {
        name: 'Guitarra',
        price: 70000,
        category: 'instrumentosMusicales',
        img: 'images/guitarra.jpg',
        description: `Para los guitarristas que valoran el estilo, el 
        sonido rico y versátil y su excelente valor intrínseco, la Stratocaster® 
        Standard es un instrumento clásico elegante y a la vez asequible, que combina 
        un diseño tradicional con especificaciones actuales. El venerado estilo de 
        Fender y las actualizaciones modernas pueden ser compatibles y este modelo 
        ofrece lo mejor de ambos mundos, en un instrumento ideal para guitarristas de 
        cualquier nivel.<br>
        <br>
        CARACTERÍSTICAS<br>
        Mástil tintado con perfil posterior en C<br>
        Diapasón de palosanto o arce con 21 trastes medium jumbo<br>
        Tres pastillas de bobinado simple con selector de cinco posiciones<br>
        Cavidades interiores apantalladas<br>
        Golpeador en acabado color pergamino<br>
        Puente con palanca de vibrato estilo vintage synchronized con<br>
        bloque del puente de alta densidad
        Logotipo de la pala de gran tamaño estilo años 70<br>
        <br>
        AUTHENTIC FENDER TONE AND STYLING<br>
        Puro y simple, este instrumento ofrece el sonido clásico de 
        Fender que evoca y hace honor a los referentes de la marca, que 
        contribuyeron a su ADN esencial. Desde el acorde más suave hasta la nota más fuerte, 
        y desde el botón del enganche de la correa hasta la punta de la pala, este instrumento 
        representa la verdadera esencia del diseño clásico de Fender.<br>
        <br>
        MODERN NECK WITH “C” PROFILE<br>
        Este instrumento consta de un mástil moderno diseñado para mayor 
        comodidad y rendimiento, con un perfil en C, ( silueta de la sección 
        transversal del mástil), y un acabado posterior de especial suavidad, ideal
        para los guitarristas que se apoyan con el pulgar en la parte posterior o 
        lateral del mástil.<br>
        <br>
        FENDER CUSTOM SHOP SINGLE-COIL PICKUPS<br>
        En más de medio siglo de historia de Fender y de la música 
        moderna, no hay nada como el sonido clásico ya sea cantarín, orgánico, 
        chillón o cristalino de las pastillas Fender Custom Shop de bobinado simple.`
    },
    {
        name: 'Amplificador',
        price: 30000,
        category: 'homeStudio',
        img: 'images/amplificador.jpg',
        description: `Amplificador Fender 65 Princeton Reverb Valve Combo
        El tono vintage que solo un valvular puede lograr.<br>
        <br>
        FENDER ´65 PRINCETON REVERB<br>
        Amplificador de guitarra combo valvular de 15W con rever. bEl legendario Princeton 
        Reverb de los 60s era pequeño, ligero y moderadamente potente. Aunque orientado 
        para sesiones de práctica, este vintage era capaz de un gran tono valvular, incluyendo 
        los clásicos efectos de Reverb y Vibrato con el inconfundible sonido Fender. Y desde 
        su concepción hasta nuestros días ha formado el equipo de numerosos guitarristas que 
        lo han acogido como el amplificador de estudio predilecto, completo con un stomp box 
        de dos switches para controlar fácilmente los colores de sus efectos.<br>
        <br>
        Hoy, el original Princeton Reverb se ha convertido en un coleccionable invaluable, 
        cada vez más difícil de conseguir. El nuevo ’65 PRV ofrece a los guitarristas 
        amantes del vintage todo el tono y la dinámica de esta vieja leyenda en una reedición o
        ptimizada y extremadamente versátil.<br>
        <br>
        El robusto amp de 15 Watts de potencia es una sabia elección para crear tonos 
        valvulares en espacios compactos, brindando incluso una plataforma con el output 
        óptimo para pequeñas realizaciones y ensayos.<br>
        <br>
        ESPECIFICACIONES<br>
        – Amplificador combo valvular de guitarra Vintage Reissue Series<br>
        – Potencia de salida: 15W en 8 ohms<br>
        – Parlante 1×10″ Jensen Special Design C-10R<br>
        – Canal simple de 2 entradas<br>
        – Controles de Volume, Treble, Bass, Reverb, Speed, Intensity<br>
        – Perillas tipo vintage witch-hat negras<br>
        – Efecto de Reverb y Vibrato integrados<br>
        – Válvulas de Pre 3x 12AX7s / 1x 12AT7<br>
        – Válvulas de Potencia: 2x 6V6s<br>
        – Válvula rectificadora 1x 5AR4<br>
        – Cobertura de vinilo negra texturada con frente de grilla textil plateada<br>
        – Gabinete de construcción en Pino<br>
        – Manija de transporte superior de plástico moldeado con enganches de nickel<br>
        – Footswitch de 2 botones para reverb y vibrato incluido`
    },
    {
        name: 'Piano',
        price: 85000,
        category: 'instrumentosMusicales',
        img: 'images/piano.jpg',
        description: `PIANO ELECTRICO 88 NOTAS
        TECLAS PESADAS " GRADED HAMMER STANDARD" (GHS)<br>
        *POLIFONIA: 192 NOTAS <br>
        LA POLIFONIA ES EL NUMERO MAXIMO DE NOTAS DE UNO O VARIOS SONIDOS<br>
        QUE EL MOTOR DE SINTESIS ES CAPAZ DE PRODUCIR SIMULTANEAMENTE<br>
        EL USO DEL PEDAL DE SUSTAIN CONSUME POLIFONIA (MANTIENE ACTIVAS LAS NOTAS
        QUE ESTUVIERAN SONANDO)<br>
        NO ASI LA REVERB, YA QUE ES UN EFECTO INDEPENDIENTE DEL MOTOR DE SINTESIS
        Y NO AFECTA A LA POLIFONIA<br>
        LA CONCLUSION ES QUE, CUANTAS MAS NOTAS DE POLIFONIA, MAS CERCA VAS A ESTAR
        DEL SONIDO AUTENTICO DEL PIANO ACUSTICO<br>
        VOCES: 14<br>
        SE REFIERE A SONIDOS DE INSTRUMENTOS DESDE PIANOS, ORGANOS, GUITARRAS, 
        ODA LA GAMA DE
        POSIBLES INSTRUMENTOS INCLUYENDO VOCES HUMANAS COMO COROS ETC.<br>
        SE CUENTA COMO ESPACIOS DE AUDIO, AL NUMERO DE PRESETS QUE TIENE EL TECLADO
        CADA VOZ ES UN INSTRUMENTO VIRTUAL. SIMPLEMENTE ES UN NOMBRE PARA DEFINIR 
        STE ESPACIO<br>
        APLICACIONES: CONTROLADOR PIANO DIGITALPARA DISPOSITIVOS "IOS".
        ESTA APLICACION PERMITE AL EJECUTANTE CONTROLAR EL TECLADO DESDE EL DISPOSITIVO,
        PARA (ENTRE OTRAS COSAS) PODER CAMBIAR LA CONFIGURACION Y LOS SONIDOS MAS CONVENIENTES. 
        ACTUALMENTE ESTE DISPOSITIVO DEBE ESTAR CONECTADO AL PIANO YA QUE NO HAY NINGUNA OPCION INALAMBRICA.<br>
        HAY 14 VOCES DE SONIDO Y PUEDEN SER AUN MAS FACIL DE CONTROLAR CON EL USO DE 
        PLICACIONNES DESCARGABLES QUE PROPORCIONA YAMAHA<br>
        *SONIDO DE PIANO: AMW STEREO SAMPLING<br>
        SE REFIERE A UN SONIDO GENERADO A TRAVEZ DE UN SAMPLEO DE PIANO ACUSTICO<br>
        ES ESTA TECNOLOGIA DE SAMPLEO QUE GRACIAS A SUS 4 CAPAS DE GRABACION SE PUEDA LOGRAR QUE
        LAS NOTAS MAS GRAVES SEAN MAS PROLONGADAS, Y TANTO LOS MEDIOS COMO LOS AGUDOS SEAN MAS CORTAS
        LOS MISMOS SAMPLEOS DE ATAQUE Y LOOP SON LO SUFICIENTEMENTE CORTOS PARA ASI PODER CONTRIBUIR
        CUANDO LAS NOTAS TIENEN QUE CAER (EN INTENSIDAD DE SONIDO)<br>
        LOS ATAQUES Y LOOPS SON ALTAMENTE PROCESADOS PARA LO  
        GRAR SONIDOS MAS REALISTAS Y ASI EVITAR EL DEFASAJE EN LAS ONDAS SAMPLEADAS<br>
        PURE CF SOUND ENGINE: LOS TECNICOS DE YAMAHA ELIGIERON UN CONCIERTO PARA OBTENER 
        NA CALIDAD SUPERIOR DE AUDIO, Y LOGRARON SINTONIZAR LAS MEJORES CONDICIONES POSIBLES.<br>
        A TODO ESTO JUNTO SE LO CONOCE COMO EL METODO "CF PURE", LOGRAN CONJUGAR TODOS 
        OS SONIDOS PARA CONSTRUIR UN INSTRUMENTO ELECTRICO LOS MAS PARECIDO AL ACUSTICO POSIBLE, 
        Y ASI PODER DISFRUTAR DEL SONIDO NATURAL DE UN INSTRUMENTO DE ALTA GAMA.<br>
        *EFECTOS: REVERB 4 TIPOS, BOOST SOUND    <br>
        *SENSIBILIDAD DE TOQUE: DURO/MEDIO/LIVIANO/FIJO<br>
        *CONTROL ACUSTICO INTELIGENTE (IAC)<br>
        *TRACKS DE GRABACION: 2<br>
        *AMORTIGUADOR DE RESONANCIA<br>
        *ALMACENAMIENTO: PUERTO USB<br>
        *CONECTIVIDAD: FUENTE EXTERNA 12V.<br>
        *SALIDA DE AURICULARES: 6.5<br>
        *PEDAL DE SUSTAIN<br>
        *SALIDA AUXILIAR: (L/L+R) (R) SE PUEDE CONECTAR EL TECLADO A UN MEZCLADOR O BAFLE
        POTENCIADO SIN CORTAR LOS PARLANTES DEL PIANO, Y ASI PODER USAR ESTOS COMO MONITOREO<br>
        *FUNSION ARPEGIO: ESTA FUNCION, COMO BIEN LO INDICA LA PALABRA, GENERA ARPEGIOS
        AUTOMATCAMENTE BASADOS EN ACORDES<br>  
        *EFECTOS:<br>
        *DUAL/LAYER:<br>
        DOBLE CAPA (DUAL/LAYER) SE REFIERE A UNA TECNOLOGIA DE GRABACION QUE OFRECE
        A LOS USUARIOS
        UN ESPACIO DE 8.5GB (EN COMPARACION DE LOS 4,7GB DE CAPACIDAD STD)<br>
        EL ESPACIO DE GRABACION ADICIONAL ES EL RESULTADO DIRECTO DE LA TECNOLOGIA 
        DOBLE CAPA"
        (OPTIMIZA LA CAPACIDAD Y CALIDAD DE ALMACENAMIENTO DE EFECTOS)<br>
        CON ESTA TECNICA SE PUEDE REPRODUCIR DOS O MAS SONIDOS DIFERENTES AL MISMO
        TIEMPO EN UNA DE LAS CLAVES.<br>
        SERA CAPAZ DE TOCAR (POR EJ.) PIANO Y CUERDAS, PIANO Y ORGANO SIMULTANEAMENTE 
        N UNA CLAVE<br>
        SE PUEDE EJECUTAR DOS INSTRUMENTOS DE DIFERENTES SONIDOS EN CADA MANO<br>
        EJ. LA MANO IZQUIERDA PUEDE TOCAR UN VIBRATONE, MIENTRAS QUE LA DERECHA PUDE 
        OCAR UN PIANO
        DE ESTA MANERA DE LOGRA EL EFECTO DE TOCAR DOS INSTRUMENTOS DIFERENTES AL
        MISMO TIEMPO Y POR LA MISMA PERSONA<br> 
        <br>
        
        *FUNCION SPLIT MODE: DIVIDIR EL TECLADO Y TOCAR DOS SONIDOS DIFERENTES.<br>
        EL MODO SPLIT PERMITE REPRODUCIR DOS SONIDOS DIFERENTES EN EL TECLADO. UNO CON
        LA MANO DERECHA Y OTRO CON LA MANO IZQUIERDA
        POR EJ. PUEDE TOCAR UN BAJO CON LA MANO IZQUIERDA Y UNA MELODIA DE PIANO CON LA 
        ANO DERECHA<br>
        <br> 
        
        
        *ESTILO DE PIANISTA: 1ARPEGIO/2MARCHA/3RAP/4BOOGIE/5SWING/6BLUES/7SLOW ROCK/8JAZZ 
        ALLAD/9WALTZ/10 JAZZ WALTZ<br>
        *FUNCION TITMICA: 10 ESTILOS INTEGRADOS PARA PRACTICAR DISTINTOS RITMOS, COMO POR 
        J:1 8BEAT/2 16 BEAT/3 TRIPLE BEAT/4SWING/5 MARCHA/6 MARCHA 6/8 /7 BOSSANOVA/ 8 SAMBA/ 9WALTZ/ 10 JAZZ  WALTZ. ADEMAS CUENTA CON 10 PATRONES DE BATERIA<br>
        *DEMO: 14 MAS 50 SONIDOS DE PIANO<br>
        *METRONOMO<br>
        *RANGO DE TEMPO: 5/280<br>
        *TRANSPORTE DEL TECLADO: (-6 A 0. DE 0 A +6)<br>
        *AFINACION: 414.8-440.0-446.8HZ<br>
        *AMPLIFICADOR: 7WTS X 2 (14Wts)<br>
        *PARLANTES: DE 12Cm X 2 + 5Cm x 2<br>
        *ANCHO: 1.33Mts<br>
        *ALTURA: 16.3 Cmts.<br>
        *PROFUNDIDAD: 29.5 Cmts.<br>
        *PESO: 11.8kG`
    },
    {
        name: 'Bundle',
        price: 90000,
        category: 'promociones',
        img: 'images/bundle.jpg',
        description: `PACK PREMIUM COMPLETO ROCK<br>
        <br>
        + GUITARRA ELÉCTRICA 3 MICRÓFONOS<br>
        Diferentes colores según stock (seleccionar en las opciones)<br>
        + AMPLIFICADOR 15W<br>
        + FUNDA<br>
        + CABLE<br>
        + AFINADOR CROMÁTICO CLIP<br>
        + PÚA<br>
        + PALANCA<br>
        + LLAVES PARA CALIBRAR<br>
        <br>
        /// ENVIO A TODO EL PAIS ///<br>
        <br>
        Tené el mejor pack del mercado de guitarra eléctrica, <br>
        amplificador y accesorios.<br>
        <br>
        Características:<br>
        Construidas en madera maciza (basswood)<br>
        Mástil en Maple<br>
        Trastera de Palisandro<br>
        Herrajes Cromados<br>
        Palanca Vibrato<br>
        3 micrófonos<br>
        Controles de tono<br>
        Control de volumen<br>
        Llave selectora de micrófono de 5 posiciones<br>
        Tensor en el mástil<br>
        Pickguard<br>
        Clavijas cromadas<br>
        Acabado brillante<br>
        Diferentes colores (según stock)<br>
        Pines para colocación de correa<br>
        <br>
        Colores Gypsy en medida 7/8<br>
        <br>
        GARANTÍA OFICIAL`
    },
    {
        name: 'Placa de audio',
        price: 53000,
        category: 'homeStudio',
        img: 'images/placa%20de%20audio.jpg',
        description: `Contar con una buena calidad de sonido a la hora de 
        grabar tus pistas es muy importante para dar el salto de amateur a 
        profesional. Es por eso que esta interface de audio Focusrite Solo 
        Scarlett es la indicada para vos.<br>
        <br>
        Lográ la grabación completa<br>
        Este aparato cuenta con 2 entradas, lo que te permitirá ingresar 
        varios sonidos a la vez. La regla es que necesitás tantas entradas 
        como líneas quieras grabar simultáneamente, es decir que podrás 
        utilizarla para micrófonos e instrumentos y obtener una grabación 
        completa de una sola vez. Además, cuenta con 2 salidas que te 
        permitirán conectar a tu computadora y así hacer el trabajo de forma integral.<br>
        <br>
        Sumá calidad<br>
        Gracias a sus 192 kHz y su resolución de audio de 24 bit vas a 
        lograr que todas tus grabaciones tengan una calidad sobresaliente y 
        se resalten las melodías de cada instrumento y cada voz.<br>
        <br>
        Poder fantasma activo<br>
        Para dar más potencia a la señal que conectes a la interface, este 
        producto cuenta con alimentación fantasma o phantom, que optimiza la señal y 
        brinda corriente de manera constante a todos los dispositivos de audio que conectes.`
    },
];

const main = document.querySelector('main');
const productContainer = document.querySelector('.productContainer');

const showDescription = (e)=>{
    let currentTarget = e.currentTarget.getAttribute('id');
    let currentProduct = productStock.find((item)=>{
        return item.name === currentTarget;
    });
    let backgroundBlocker = document.createElement('div');
    backgroundBlocker.classList.add('disableBackground');
    backgroundBlocker.addEventListener('click', removeDescription);
    backgroundBlocker.innerHTML= `
        <div class="productDescription">
            <div class="imageDescription">
                <div class="imgContainer">
                    <img src="${currentProduct.img}" alt="${currentProduct.name}">
                </div>
                <div class="description">
                    <p class="descriptionTitle">Descripción</p>
                    <p class="descriptionText">${currentProduct.description}</p>
                </div>
            </div>
            <div class="nameButtons">
                <p class="name">${currentProduct.name}</p>
                <p class="price">$${currentProduct.price}</p>
                <label for="amount" class="amountLabel">Cantidad</label>
                <input type="number" id="amount" class="amountInput" placeholder="1" 
                value="1" min="1" required>
                <div class="buy">Comprar</div>
                <p class="or">ó</p>
                <div class="addToCart">Agregar al carrito</div>
                <div class="return">Regresar</div>
            </div>
        </div>
    `;
    main.appendChild(backgroundBlocker);
}

const removeDescription = (e)=>{
    let backgroundBlocker = document.querySelector('.disableBackground');
    let currentTarget = e.target.getAttribute('class');
    switch(currentTarget){
        case 'disableBackground':
        case 'buy':
        case 'addToCart':
        case 'return':
            backgroundBlocker.remove();
    }
}

const renderProducts = ()=>{
    for(let el of productStock){
        let productCardContainer = document.createElement('div');
        productCardContainer.classList.add('productCardContainer');
        productCardContainer.setAttribute('name', `${el.category}`);
        productCardContainer.setAttribute('id', `${el.name}`);
        productCardContainer.addEventListener('click', showDescription);
        productCardContainer.innerHTML = `
            <div class="productCard">
                <div class="img">
                    <img src=${el.img} alt="placa de sonido">
                </div>
                <div class="productCardText">
                    <p class="productName">${el.name}</p>
                    <p class="productPrice">$${el.price}</p>
                </div>
                <div class="seeMore">Ver más</div>
            </div>
        `;
        productContainer.appendChild(productCardContainer);
    }
}

const clearScreen = ()=>{
    const productCardContainer = document.querySelectorAll('.productCardContainer');
    for(let el of productCardContainer){
        el.remove();
    }
}

const renderFilteredProducts = (e)=>{
    clearScreen();
    let currentCategory = e.target.getAttribute('id');
    if(currentCategory === 'todos'){
        renderProducts();
        return;
    }
    let output = productStock.filter((product)=>{
        return product.category === currentCategory;
    });
    
    for(let el of output){
        let productCardContainer = document.createElement('div');
        productCardContainer.classList.add('productCardContainer');
        productCardContainer.setAttribute('name', `${el.category}`);
        productCardContainer.setAttribute('id', `${el.name}`);
        productCardContainer.addEventListener('click', showDescription);
        productCardContainer.innerHTML = `
            <div class="productCard">
                <div class="img">
                    <img src=${el.img} alt="${el.name}">
                </div>
                <div class="productCardText">
                    <p class="productName">${el.name}</p>
                    <p class="productPrice">$${el.price}</p>
                </div>
                <div class="seeMore">Ver más</div>
            </div>
        `;
        productContainer.appendChild(productCardContainer);
    }

}

const categories = document.querySelectorAll('.individualCategory');

for(let el of categories){
    el.addEventListener('click', (e)=>{
        clearScreen();
        renderFilteredProducts(e);
    })
}

renderProducts();