alert('Bienvenido a AudioStore!');

const productCart = [];

const getProduct = ()=>{
    let product = prompt('Ingresa el nombre del producto que desees comprar (guitarra, amplificador o bundle):', '');
    if(product === null) return '';
    return product.toLowerCase();
}
    
const getAmount = ()=>{
    amount = parseInt(prompt('Cuántos quieres comprar? La cantidad mínima es 1:', 1));
    while(amount < 1 || isNaN(amount)){
        alert('La cantidad ingresada no es válida');
        amount = getAmount();
    }
    return amount;
}

const discountPrice = (total)=>{
    let discount = total * 0.2;
    return total -= discount;
}
    
const checkProduct = (product)=>{
    switch(product){
        case 'guitarra':
            alert('El precio de la guitarra es de 70mil pesos.');
            break;
        case 'amplificador':
            alert('El precio del amplificador es de 30mil pesos.');
            break;
        case 'bundle':
            alert('El precio del bundle guitarra-amplificador es de 90mil pesos.');
            break;
        default:
            alert('Producto no válido');
            return 'invalid';
    }
}

class Product {
    constructor(name, price, amount) {
        this.name = name,
        this.price = price,
        this.amount = amount,
        this.total = this.price * this.amount;
    }
    // este método actualiza el la propiedad total, y se va a ejecutar cuando el usuario
    // agregue más cantdad a un producto que ya tenga en su carrito
    updateTotal(){
        this.total = this.price * this.amount;
    }
}

// Esta función chequea si el producto que el usuario está tratando de agregar al carrito
// ya existe
const checkExistentProduct = (product)=>productCart.some((item) => item.name === product);

// esta función se ejecuta cada vez que el usuario agregue un producto que ya tenga en su carrito
// y agrega la cantidad seleccionada al objeto del producto que ya se encuentra en el carrito
// en lugar de crear un objeto nuevo
const addToExistentProduct = (product, amount) =>{
    let output = productCart.find((item)=>{
        return item.name === product;
    });
    let outputIndex = productCart.indexOf(output);
    productCart[outputIndex].amount += amount;
    productCart[outputIndex].updateTotal();
}

const createProduct = (product, amount)=>{
    let productCheck = checkExistentProduct(product);
    if(productCheck){
        addToExistentProduct(product, amount);
        return;
    }
    switch(product){
        case 'guitarra':
            let guitarra = new Product('guitarra', 70000, amount);
            productCart.push(guitarra);
            return guitarra;
        case 'amplificador':
            let amplificador = new Product('amplificador', 30000, amount);
            productCart.push(amplificador);
            return amplificador;
        case 'bundle':
            let bundle = new Product('bundle', 90000, amount);
            productCart.push(bundle);
            return bundle;
    }
}

//esta función cicla a través del array y suma las propiedades .total de todos los objetos
const calculateTotal = ()=>{
    let total = 0;
    for(let el of productCart){
        total += el.total;
    }
    return total;
}

const askDiscount = ()=> confirm('Tienes un código de descuento?');

const getDiscount = ()=> prompt('Ingresa el código de descuento:', '');

const checkDiscountCode = (discountCode, hasDiscount)=>{
    // esto en caso de que el usuario introduzca un cupón de descuento no válido
    while(discountCode !== 'descuento'){
        alert('Código no válido');
    
        // esto en caso de que el usuario se haya equivocado y no tenga cupón de descuento
        hasDiscount = askDiscount();
        if(!hasDiscount){
            return false;
        }
    
        discountCode = getDiscount();
    }
    alert('Código de descuento aplicado!');
    return true;
}

const confirmPurchase = (discountCodeChecker, amountDiscounted, total)=>{
    let purchase = false;

    if(discountCodeChecker){
        amountDiscounted = total * 0.2;
        total = discountPrice(total);
        purchase = confirm(`El total de tu compra con descuento es de ${total} pesos. Confirmar compra?`);
    } else{
        purchase = confirm(`El total de tu compra es de ${total} pesos. Confirmar compra?`);
    }

    if(purchase){
        alert('Gracias por comprar en AudioStore!');
        alert(createReceipt(total, discountCodeChecker, amountDiscounted));
    } else{
        alert('Compra cancelada');
    }
}

const createReceipt = (total, discountCodeChecker, amountDiscounted)=>{
    let receipt = 'RECIBO:\n';
    for(let el of productCart){
        receipt += `${el.name} (${el.amount}u) = $${el.total}\n`
    }
    if(discountCodeChecker) receipt += `DESCUENTO = $${amountDiscounted} (20%OFF)\n`;
    receipt += `TOTAL = $${total}`
    return receipt;
}

const buyProduct = ()=>{
    let total = 0;
    let moreProduct = false;

    buy:do{
        let product = getProduct();
        
        let productChecker = checkProduct(product);
    
        while(productChecker === 'invalid'){
            moreProduct = confirm('Deseas agregar otro producto?');
            // esto en caso de que el usuario se haya equivocado y no quiera comprar otro producto
            if(!moreProduct){
                break buy;
            }
            product = getProduct();
            productChecker = checkProduct(product);
        }
    
        let amount = getAmount();

        createProduct(product, amount);
    
        total = calculateTotal();
        alert(`El total actual de su compra es de ${total}`);
        moreProduct = confirm('Deseas agregar más productos?');
        
    } while(moreProduct);
    
    if(total === 0){
        alert('Compra cancelada')
        return;
    }
    
    alert(`El total de tu compra es de ${total} pesos.`);

    let hasDiscount = askDiscount();
    let discountCode;
    let discountCodeChecker;

    if(hasDiscount){
        discountCode = getDiscount();
        discountCodeChecker = checkDiscountCode(discountCode, hasDiscount);
    }
    let amountDiscounted = 0;

    confirmPurchase(discountCodeChecker, amountDiscounted, total);
}

buyProduct();
